<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['site_name'] = 'ChemWaste';

$config['favicon']	= '';

$config['copy_right'] = '2019 © Chem Waste All Rights Reserved.';