<div class="page-body">
	<div class="container">
		<div class="section-title">
			<h3>Home</h3>
			<div class="announce-images">
				<div class="row">

				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(document).ready(function() {
		$('#home a').removeClass('nav-color');
		$('#home a').addClass('nav-active');
	});
</script>